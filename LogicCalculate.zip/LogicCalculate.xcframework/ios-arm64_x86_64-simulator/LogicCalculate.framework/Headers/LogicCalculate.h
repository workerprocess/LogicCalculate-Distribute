//
//  LogicCalculate.h
//  LogicCalculate
//
//  Created by ekachai mankongtongjaroen on 10/10/2566 BE.
//

#import <Foundation/Foundation.h>

//! Project version number for LogicCalculate.
FOUNDATION_EXPORT double LogicCalculateVersionNumber;

//! Project version string for LogicCalculate.
FOUNDATION_EXPORT const unsigned char LogicCalculateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LogicCalculate/PublicHeader.h>


